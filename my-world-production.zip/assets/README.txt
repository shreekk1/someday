Place all your images in this folder.

Required files:
  IMG_8090.jpeg
  IMG_5749.jpeg
  IMG_4731.jpeg
  IMG_4726.jpeg
  IMG_2441.jpeg
  IMG_3759.gif
  IMG_4474.jpeg
  IMG_4717.jpeg
  IMG_4656.jpeg
  IMG_3519.jpeg
  IMG_7707.jpeg
  C2E79B65-3C67-4763-81C0-B8DAB4C4CCE3.jpeg

These should be moved here from /mnt/user-data/uploads/ on your local machine.
Rename them or update the src= paths in index.html if needed.
